const CONFIG = {
  repeat: "100", // Ustaw na liczbę np 20 albo off
};

chrome.runtime.onMessage.addListener(async (message) => {
  if (message.action === "fill") {
    const lang = message.language;

    const runOnce = async () => {
      const inputElement = document.querySelector("#flashcard_answer_input");
      const enterButton = document.querySelector("#enterBtn");

      if (!inputElement && enterButton) {
        console.log("Brak pola odpowiedzi - klikam Dalej");
        enterButton.click();
        return;
      }

      const wordElement = document.querySelector("#flashcard_main_text");

      if (!wordElement || !enterButton) {
        console.log("Brakuje elementów na stronie!");
        return;
      }

      const word = wordElement.textContent.trim();
      console.log("Szukam tłumaczenia dla:", word);

      try {
        const response = await fetch(chrome.runtime.getURL(`${lang}.json`));
        const translations = await response.json();

        let translated = null;
        for (const key in translations) {
          if (key.toLowerCase() === word.toLowerCase()) {
            translated = translations[key];
            break;
          }
        }

        if (translated) {
          inputElement.value = translated;
          inputElement.focus();
          inputElement.dispatchEvent(new Event("input", { bubbles: true }));
          inputElement.dispatchEvent(new Event("change", { bubbles: true }));
          enterButton.click();
        } else {
          alert(`Brak tłumaczenia dla: ${word}`);
        }
      } catch (err) {
        console.error("Błąd ładowania pliku JSON:", err);
      }
    };

    // Jeśli repeat to liczba – powtórz tyle razy
    if (CONFIG.repeat !== "off") {
      const repeatCount = parseInt(CONFIG.repeat);
      for (let i = 0; i < repeatCount; i++) {
        await runOnce();
        await new Promise((r) => setTimeout(r, 50));
      }
    } else {
      await runOnce();
    }
  }
});
