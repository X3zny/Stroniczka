document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("fillButton");
  const select = document.getElementById("languageSelect");

  btn.addEventListener("click", () => {
    const language = select.value;

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      const url = tab.url || "";

      if (url.includes("lingos.pl")) {
        chrome.tabs.sendMessage(
          tab.id,
          {
            action: "fill",
            language: language,
          },
          (response) => {
            if (chrome.runtime.lastError) {
              console.warn(
                "Błąd podczas wysyłania wiadomości:",
                chrome.runtime.lastError.message
              );
            }
          }
        );
      } else {
        console.warn("Bot działa tylko na lingos.pl");
      }
    });
  });
});
